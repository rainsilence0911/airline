air.define("air.event.Events", function() {
    
    return {
        ITEM_SELECT: "item_select",
        ITEM_REMOVE: "item_remove",
        ITEM_ADD: "item_add"
    };
});